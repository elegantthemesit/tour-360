var APP_DATA = {
  "scenes": [
    {
      "id": "0-ingresso-01",
      "name": "Ingresso #01",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2000,
      "initialViewParameters": {
        "yaw": -1.8196890090565319,
        "pitch": 0.2813363076100046,
        "fov": 1.2848690214557934
      },
      "linkHotspots": [
        {
          "yaw": -1.8307396948165735,
          "pitch": 0.3355518256526935,
          "rotation": 0,
          "target": "1-open-space"
        },
        {
          "yaw": -2.092099025555452,
          "pitch": -0.03888517082676124,
          "rotation": 0,
          "target": "3-ingresso-02"
        },
        {
          "yaw": -2.5311797553198527,
          "pitch": 0.01491808746871115,
          "rotation": 0,
          "target": "2-angolo-cottura"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -1.33677157958925,
          "pitch": 0.22306284564507806,
          "title": "Divano letto",
          "text": ""
        },
        {
          "yaw": -1.6528261598402256,
          "pitch": 0.08234239767545048,
          "title": "Accesso Internet",
          "text": ""
        },
        {
          "yaw": 2.177117007309148,
          "pitch": 0.06652969082497151,
          "title": "uscita condominio",
          "text": ""
        },
        {
          "yaw": 1.9911699574256492,
          "pitch": 0.5082460187654441,
          "title": "Accesso con APP",
          "text": ""
        },
        {
          "yaw": -0.7039941669772922,
          "pitch": 0.08845909809045871,
          "title": "Smart TV",
          "text": ""
        }
      ]
    },
    {
      "id": "1-open-space",
      "name": "Open Space",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2000,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0.5083599728838042,
          "pitch": 0.040723566878520856,
          "rotation": 0,
          "target": "0-ingresso-01"
        },
        {
          "yaw": 2.3277384100477834,
          "pitch": 0.11527576583384302,
          "rotation": 0,
          "target": "2-angolo-cottura"
        },
        {
          "yaw": 2.845589648540157,
          "pitch": 0.08654345423264331,
          "rotation": 0,
          "target": "4-bagno"
        },
        {
          "yaw": -3.0168461241968334,
          "pitch": -0.03370504424291454,
          "rotation": 0,
          "target": "3-ingresso-02"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -0.34138220260715,
          "pitch": 0.22622768292515794,
          "title": "Divano letto",
          "text": ""
        },
        {
          "yaw": -1.8129454207380213,
          "pitch": 0.19541077510376503,
          "title": "Internet",
          "text": ""
        }
      ]
    },
    {
      "id": "2-angolo-cottura",
      "name": "Angolo cottura",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2000,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0.8188564645820371,
          "pitch": 0.027616173445055736,
          "rotation": 0,
          "target": "0-ingresso-01"
        },
        {
          "yaw": 0.2510737270439165,
          "pitch": 0.09358002086819717,
          "rotation": 0,
          "target": "1-open-space"
        },
        {
          "yaw": -1.1282610065112202,
          "pitch": -0.03296937462054217,
          "rotation": 0,
          "target": "3-ingresso-02"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 2.3071069070077277,
          "pitch": 0.21944557598486014,
          "title": "Apertura su chiostrina",
          "text": ""
        }
      ]
    },
    {
      "id": "3-ingresso-02",
      "name": "Ingresso #02",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2000,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 1.1865247731452904,
          "pitch": 0.39694931928007193,
          "rotation": 0,
          "target": "2-angolo-cottura"
        },
        {
          "yaw": 2.1266607843669645,
          "pitch": 0.357317777782562,
          "rotation": 0,
          "target": "4-bagno"
        },
        {
          "yaw": 0.5224444346080848,
          "pitch": 0.1356176714873012,
          "rotation": 0,
          "target": "0-ingresso-01"
        },
        {
          "yaw": 0.28804122015471023,
          "pitch": 0.36580456139647133,
          "rotation": 0,
          "target": "1-open-space"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 0.033493907577092585,
          "pitch": 0.22476845804897394,
          "title": "Divano letto",
          "text": ""
        }
      ]
    },
    {
      "id": "4-bagno",
      "name": "Bagno",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2000,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0.07660565481538129,
          "pitch": 0.05933597866430418,
          "rotation": 0,
          "target": "3-ingresso-02"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Il Rifugio ",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
